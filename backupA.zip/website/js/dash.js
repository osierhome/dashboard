var websock;
window.incomingMessage;
window.consout = "";
window.statsOn = ['stat0','stat1','stat2','stat3'];
window.togLED0 = document.getElementById("led0");
window.togLED1 = document.getElementById("led1");
window.togLED2 = document.getElementById("led2");
window.togLED3 = document.getElementById("led3");
	
function connect() {
	websock = new WebSocket("ws://192.168.7.2:1880/dash");
	websock.onopen = onOpen;
	websock.onclose = onClose;
	websock.onmessage = onMessage;
	websock.onerror = onError;
} function onOpen(evt) {
	consout += "Opened socket<br />";
	printConsole();
	getStat();
} function onClose(evt) {
	consout += "Closed socket<br />";
	printConsole();
} function onMessage(evt) {
	consout += "Message received<br />";
	printConsole();
	updateStat(evt.data);
} function onError(evt) {
	consout += "Whooops..<br />";
	printConsole();
}

function getStat() {
	websock.send(statsOn);
} function updateStat(statStr) {
	var statUpdate = statStr.split(':');
	document.getElementById(statUpdate[0]).innerHTML = statUpdate[1];
}

function sendCMD(command) {
	var cmd = 'cmd' + command;
	websock.send(cmd);
}

function browserValidate() {
	if ("WebSocket" in window) {
		consout += "Browser supported<br />";
		printConsole();
		connect();
	} else {
		consout += "Browser doesn't support HTML5 WebSockets<br />";
		printConsole();;
	}
}

function printConsole() {
	document.getElementById("consoleOut").innerHTML = consout;
}